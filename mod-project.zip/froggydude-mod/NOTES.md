# Froggydude - Parte 1: combate consertado

Mod para Minecraft 1.20.1 / Forge. Estamos indo por partes:

- Parte 1 (este zip): combate. Língua mirando certo e com o tamanho certo,
  pulos calculados (só pula se acerta, sem dano de queda), jogador preso de
  verdade (sem zoom), IA sem indecisão.
- Parte 2 (próxima): fase 2 (contorção, grito, corrida) e animações.
- Parte 3: skins reais e as variantes por tipo de dano.

Nesta parte a fase 2 está DESLIGADA de propósito (FroggyFrenzyGoal existe
mas não é registrada), pra testar só o combate.

O que testar agora, e me contar:
1) a língua sai na direção de quem ele está atacando? chega até você?
2) ele só pula quando vai te acertar? cai sem tomar dano?
3) quando o pulo ou a língua de captura te acerta, você fica sem poder se
   mexer por uns 2 segundos, com a tela tremendo e inclinada?
4) ele ainda fica indeciso, parado sem atacar?

IMPORTANTE: eu não consegui compilar isso aqui. Se o build reclamar de
algo, me manda a mensagem de erro que eu corrijo.

## O que tem no pacote
Código (src/main/java/com/froggydude):
- entity/FroggydudeEntity.java - entidade (agora implementa GeoEntity)
- entity/FroggyState.java - estados e duração de cada um
- entity/ai/ - FroggyCombatGoal (escolhe o ataque), FroggyFeedGoal (devora
  mobs com pouca vida), FroggyFrenzyGoal (contorção + frenesi)
- client/ - FroggydudeModel, FroggydudeRenderer, ClientModEvents (registra
  o renderer) e ClientForgeEvents (tremor de câmera)
- network/ - ModNetwork, FroggyShakePacket, ClientShakeHandler
- init/ - registro da entidade e dos atributos

Recursos (src/main/resources/assets/froggydude):
- geo/froggydude.geo.json - modelo no formato de jogador (skin 64x64)
- animations/froggydude.animation.json - 16 animações (rascunho, veja abaixo)
- textures/entity/froggydude_normal_0..3.png - texturas de TESTE (verde liso
  com manchas vermelhas). Troque pelas skins reais (veja "Texturas")
- lang/ - nome da entidade

tools/prepare_skins.py - prepara as skins do NameMC (veja "Texturas")

## Montar o projeto e gerar o .jar
Este zip tem só o código e os recursos (src/). O build (build.gradle,
gradlew) vem do MDK do Forge 1.20.1 (o mesmo que você usou no FNaF,
forge-1.20.1-47.4.10-mdk).

1) Crie uma pasta nova (ex.: froggydude) a partir do MDK, separada do
   projeto do FNaF.
2) Apague o código de exemplo do MDK: a pasta
   src/main/java/com/example/examplemod (ExampleMod.java e Config.java).
3) gradle.properties: mod_id=froggydude, mod_name=Froggydude,
   mod_group_id=com.froggydude
4) Copie a pasta src/ deste zip por cima (o FroggydudeMod.java já é a
   classe principal do mod).
5) build.gradle - adicione o GeckoLib:

    repositories {
        maven {
            name = 'GeckoLib'
            url 'https://dl.cloudsmith.io/public/geckolib3/geckolib/maven/'
            content { includeGroup('software.bernie.geckolib') }
        }
    }
    dependencies {
        implementation fg.deobf('software.bernie.geckolib:geckolib-forge-1.20.1:4.4.9')
    }

   (4.4.9 é a que usei e já funcionou no seu teste. Existem versões mais
   novas do GeckoLib 4 para 1.20.1 (4.7 e 4.8), mas não troque agora.)

6) src/main/resources/META-INF/mods.toml - adicione, junto das outras
   dependências:

    [[dependencies.${mod_id}]]
        modId="geckolib"
        mandatory=true
        versionRange="[4.4,)"
        ordering="NONE"
        side="BOTH"

7) Rode ./gradlew build (com Java 17). O jar sai em build/libs/.
   (build só gera o jar; ele não abre o jogo.)

Se seu mod já tem um SimpleChannel, use o seu e só copie o
registerMessage do FroggyShakePacket pra lá.

## Testar no Zalith Launcher
1) Instale uma versão 1.20.1 com Forge (de preferência a mesma 47.x do
   MDK). Use uma versão separada da do FNaF, com isolamento de versão,
   pra os mods não se misturarem.
2) Na pasta mods dessa versão, coloque DOIS jars: o do Froggydude
   (build/libs/) e o do GeckoLib 4.4.9 para Forge 1.20.1 (Modrinth ou
   CurseForge). Sem o GeckoLib o jogo não abre.
3) Abra o jogo, crie um mundo criativo com cheats e use:
   /summon froggydude:froggydude
   Depois /gamemode survival pra ele te atacar.
4) Se crashar, veja logs/latest.log e a pasta crash-reports dentro da
   pasta da versão (o gerenciador de arquivos do Zalith abre).

## Como estado, animação e ataque se conectam
O estado (FroggyState) é sincronizado servidor -> cliente. O cliente toca
a animação do estado. O servidor aplica o dano no tick de impacto. Por
isso a duração da animação = duração do estado, e o golpe cai no frame
certo. Se mudar um, mude o outro.

| Estado          | Animação        | Duração | Impacto        |
|-----------------|-----------------|---------|----------------|
| BITE            | bite            | 0,6 s   | 0,3 s          |
| TONGUE_WHIP     | tongue_whip     | 0,7 s   | 0,4 s          |
| TONGUE_GRAB     | tongue_grab     | 0,8 s   | 0,5 s          |
| TONGUE_CAPTURE  | tongue_capture  | 1,4 s   | 0,6 s e 1,0 s  |
| JUMP_PIN        | jump_pin        | 1,0 s   | 0,7 s          |
| HIGH_JUMP       | high_jump       | 1,6 s   | 1,1 s          |
| FEEDING         | feed (loop)     | 4,0 s   | -              |
| CONTORTING      | contort         | 2,5 s   | -              |
| frenesi ativo   | run_quad (loop) | -       | correndo       |
| cansado         | tired (loop)    | -       | -              |
| parado / andando| idle / walk     | -       | -              |

A língua é um osso separado ("tongue") com um controlador próprio: fica
escondida (escala ~0) e as animações tongue_*_ext esticam ela pra frente.
Ela tem comprimento fixo (8 blocos na chibatada e no agarrão, 12 na
captura), não se ajusta à distância do alvo.

## Ossos do modelo (nomes que as animações usam)
root, waist (cintura: inclina o corpo), body, head, tongue, right_arm,
left_arm, right_leg, left_leg. Se você refizer o modelo no Blockbench,
mantenha esses nomes (ou renomeie também nas animações).

## As animações são um rascunho
Eu montei as poses e os tempos por código, sem ver o resultado no jogo.
Espero que estejam no lugar certo, mas é provável que precise ajustar:
- se alguma pose sair invertida (ex.: inclinando pra trás), troque o
  sinal da rotação no Blockbench;
- a corrida de quatro (run_quad) e a contorção (contort) são as que mais
  precisam de acabamento;
- abra o .geo.json e o .animation.json no Blockbench (plugin GeckoLib)
  para refinar. Mantenha os nomes das animações.

## Texturas (skins do NameMC)
O modelo é o de jogador com braços de 4 px (skin "clássica"), 64x64. As
texturas incluídas são só de teste. Para usar as skins reais:

1) baixe as skins 64x64 do NameMC (a original e as ensanguentadas);
2) rode, da mais limpa para a mais ensanguentada:

    pip install pillow
    python tools/prepare_skins.py limpa.png leve.png media.png pesada.png

   Isso gera froggydude_0..3.png. O script também pinta de rosa a região
   da língua (pixels 56..61 x 16..18), que é vazia nas skins normais.
   Sem isso a língua fica invisível.

Pelo seu print do NameMC, minha sugestão de ordem é: a original, a #7
(sangue só na cabeça), a #4 (cabeça e peito) e a #8 (quase toda vermelha).
A #9 (com chifres) ficaria melhor para uma forma final futura.
O estágio muda sozinho pela vida: acima de 75% = 0, 50-75% = 1,
25-50% = 2, abaixo de 25% = 3.

## Tremor de tela
Já está ligado: JUMP_PIN, HIGH_JUMP e TONGUE_CAPTURE mandam um tremor
para o jogador atingido (FroggyCombatGoal -> ModNetwork.sendShake). A
intensidade e a duração estão nessas chamadas.

## O que ainda não existe
- A forma final com asas e voo (aparece no vídeo perto do fim). Precisa
  de outro modelo/animações e de um gatilho na IA.
- Som próprio (por enquanto só o som de comer do Minecraft).
- Loot table, spawn egg.
- Os números de dano, alcance, duração e cooldown são um ponto de
  partida. Ajuste em FroggyState e FroggyCombatGoal testando no jogo.
